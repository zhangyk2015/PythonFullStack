"""
注意：
    a.逻辑运算符主要用于进行逻辑判断，所以一般结合if语句或while循环使用较多
    b.逻辑运算符结合关系运算符使用较多
    c.表示假的数据：0   0.0   ""   []   ()    {}   None False等
    d.not xx:不管xx是哪种数据类型，得到的结果肯定是布尔值
      and和or得到的结果不一定是布尔值，根据具体参与运算的数据而定
"""
# 1.and:与
"""
真 and  假  ----》假
真 and  真  ----》真
假 and  假  ----》假
假 and  真  ----》假

规律：全真为真，有假为假
"""
print(True and False)   # False
print(34 and 0)  # 0
print(23.7 and 0.0)  # 0.0
print('hello' and '')  # ''
print([34,6,7] and [])  # []

print(True and 'abc')   #'abc'
print(34 and 19)  #19
print(23.7 and True)  #True
print('hello' and 88)  #88
print([34,6,7] and [45,7,8])  #[45,7,8]

print("*" * 50)

print(0 and 'faga')
print(0 and True)
print(0 and [34,56])
print(0 and 45)
print(0 and 34.19)

print(0 and 0.0)
print(0 and 0.0)
print(0 and 0.0)
print(0 and 0.0)
print(0 and 0.0)

"""
结论：
    A and B
    a.如果A为真，则A and B整体的结果为是B的值
    b.如果A为假，则A and B整体的结果是A的值，此时的B根本不会参与运算符，被称为短路原则
"""

print("*" * 50)

# 2.or:或
"""
真 or  假  ----》真
真 or  真  ----》真
假 or  假  ----》假
假 or  真  ----》真

规律：有真为真，全假为假
"""

print(True or False)   #
print(34 or 0)  #
print(23.7 or 0.0)  #
print('hello' or '')  #
print([34,6,7] or [])

print(True or 'abc')
print(34 or 19)
print(23.7 or True)
print('hello' or 88)
print([34,6,7] or [45,7,8])

print("*" * 50)

print(0 or 'faga')
print(0 or True)
print(0 or [34,56])
print(0 or 45)
print(0 or 34.19)

print(0 or 0.0)
print(0 or 0.0)
print(0 or 0.0)
print(0 or 0.0)
print(0 or 0.0)

"""
结论：
    A or B
    a.如果A为真，则A or B整体的结果为是A的值，此时的B根本不会参与运算符，被称为短路原则
    b.如果A为假，则A or B整体的结果是B的值
"""

# 3.not:非
"""
not 真 ----》假
not 假 ----》真
"""
# print(not 0)   # True
# print(not 3)   # False
# print(not '')  # True
# print(not 23.5)  # False
# print(not 'abc')  # False
# print(not [])  # True

# 4.优先级
print(3 > 5 and 10 < 15)   # False
# 优先级：算术运算符 >  关系运算符  > 逻辑运算符
print(3 + 2 == 5 and 10 < 15 * 2)  # True