# 1.语句a, b=10,20执⾏后，a的值是(   )；语句a, a = 10, 20 执⾏后，a的值是(   )
a, b = 10,20
print(a)  # 10
a, a = 10, 20
print(a)  # 20

# 2.已知数据’aaa‘,'bbb','ccc',用一个print输出，最终结果为aaa=bbb=ccc
print('aaa','bbb','ccc',sep='=')
print("%s=%s=%s" % ('aaa','bbb','ccc'))
print(f"{'aaa'}={'bbb'}={'ccc'}")

# 4.从控制台输入圆的半径，计算该圆的周长和面积，圆周率可以定义为3.14
PI = 3.14
r = float(input('请输入圆的半径：'))
length = 2 * PI * r
area = PI * r * r   # area = PI * r ** 2
print(f"周长：{length},面积:{area}")



