print('x' in 'xyz')   # True
print('x' not in 'xyz')  # False

print(66 in [34,10,99])   # False
print(66 not in [34,10,99])  # True

# 注意：成员运算符运算的结果肯定是布尔值，一般用于if语句或for循环