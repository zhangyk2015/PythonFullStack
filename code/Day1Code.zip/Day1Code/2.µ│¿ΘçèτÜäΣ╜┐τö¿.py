# 单行注释

"""
多行注释形式一
"""
'''
多行注释形式二
'''

print('hello world')

# 如果要一次性注释多行代码或取消多行代码的注释，则可以采用快捷键
# 首选选中代码，Windows:ctrl + /   Mac:command + /
print('hello world')
print('hello world')
print('hello world')
print('hello world')
print('hello world')
print('hello world')

