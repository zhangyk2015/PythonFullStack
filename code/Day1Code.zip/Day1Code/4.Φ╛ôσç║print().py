# print()是一个系统功能，表示输出，将指定的数据输出到控制台上
# print(values值,sep分隔,end结束,file文件,flush刷新)

# 1.基本使用【掌握】
# a.print():表示换行
print("start")
print()
print('over')

# b.输出单个数据
print('abc')    # 'xx'  "xxx" 字符串类型
print(19)      # 数字型：整型
print(23.5)    # 数字型：浮点型

# c.输出多个数据
print(23,56,7,87,9,9,'abc','3443',19)

# 2.进阶使用【了解】
# a.sep:分隔符，当输出多个数据的时候，默认使用空格分隔，也可以自定义其他符号
print(23,56,7,87,9,9,'abc','3443',19)
print(23,56,7,87,9,9,'abc','3443',19,sep=' ')
print(23,56,7,87,9,9,'abc','3443',19,sep='*')
print(23,56,7,87,9,9,'abc','3443',19,sep='@@@@@')

# 当输出单个数据的话，sep不起作用
print(10,sep='*')

# b.end：结束符，当一个print执行完毕，默认会有\n进行换行，也可以自定义成其他符号
print('aaaa')
print('bbbb')
print('cccc')

print('aaaa',end='\n')
print('bbbb',end='\n')
print('cccc',end='\n')

print('aaaa',234,56,67,8,89,9,end='***')
print('bbbb',end='%$$')
print('cccc',end='#@@')

