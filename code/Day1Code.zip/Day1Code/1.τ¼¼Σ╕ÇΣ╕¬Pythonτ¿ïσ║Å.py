print("hello world!")

"""
Windows:左上角file---->settings
Mac:左上角PyCharm----->Preferences

可能会出现的问题：程序无法运行，原因可能是Python环境丢失或者无效
解决方案：左上角file---->settings---》Python Project---->Python interpreter----》加载Python环境
"""