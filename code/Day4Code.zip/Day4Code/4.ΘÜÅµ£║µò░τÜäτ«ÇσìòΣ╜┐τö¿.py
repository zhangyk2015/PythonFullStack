# 1.随机数的简单获取
"""
在Python中产生随机数的方式：
方式一：
     第一步：导入模块/导入库：import  random
     第二步：num = random.randint(start,end)，闭区间【包头包尾】,步长默认为1，无法自定义步长
方式二：
     第一步：import  random
     第二步：num = random.choice(range(start,end,step))，前闭后开区间【包头不包尾】
        range(start,end,step):相当于生成了一个容器，容器中的数据是指定的区间，指定的步长
            start：开始数字，可以省略，默认为0
            end：结束数字，不可以省略
            step：步长，可以省略，默认为1，从start~end递增，则步长为正数，从start~end递减，则步长为负数

举例：
    random.randint(0,100):获取0~100之间的任意一个整数随机数
    random.choice(range(100)):获取0~99之间的任意一个整数随机数
    random.choice(range(1,100)):获取1~99之间的任意一个整数随机数
    random.choice(range(1,100,2)):获取1~99之间的任意一个奇数随机数
    random.choice(range(0,100,2)):获取0~99之间的任意一个偶数随机数

    random.choice(range(100,2)):错误写法，说明：如果end和step未被省略，则start也不能省略
"""
import random   # 注意：在实际使用中，同一个py文件中只需要导入一次
n1 = random.randint(0,100)
print(n1)
n2 = random.choice(range(100))  # 0~99   ******
print(n2)
n3 = random.choice(range(1,100)) # 1~99
print(n3)
n4 = random.choice(range(1,100,2)) # 1~99之间的奇数
print(n4)
n5 = random.choice(range(0,100,2)) # 0~99之间的偶数
print(n5)

# 错误写法：range(100,2)，此时的100表示start,2表示end，step默认为1
# n5 = random.choice(range(100,2))  # 等价于range(100,2,1)
# print(n5)

print(list(range(100,2,1)))   # []
print(list(range(100,2,-1)))  # [100,99......3]
"""
range(100,2,1)---->100 101 102....
range(100,2,-1)----->100 99 98.........3
"""

# 2.应用
# a.在10~80之间随机获取一个数，判断该数是否是3的倍数
import random
num1 = random.randint(10,80)
if num1 % 3 == 0:
    print(f"{num1}是3的倍数")
else:
    print(f"{num1}不是3的倍数")

# b.模拟彩票中奖
import random
random_num = random.choice(range(1000,10000))
guess_num = int(input("请输入一个4位数："))
if guess_num == random_num:
    print('恭喜你，中大奖了！')
else:
    print("谢谢参与！")
