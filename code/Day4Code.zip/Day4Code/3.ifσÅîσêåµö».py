"""
总结：
    a.if-else基本使用和if单分支的使用是相同的，条件的表示完全相同
    b.工作原理：根据条件是否成立，if分支和else分支只会有一个被执行
    c.else的后面没有条件
    d.总结：if-else实现了二选一的操作
"""
# 1.基本语法
num = 89
if num < 10:
    print('小于~~~~~')
else:
    print('大于~~~~~')

# 2.应用
# a.需求1：未成年人禁止进入网吧
# age = int(input('请输入你的年龄：'))
# if age < 18:
#     print('未成年人禁止进入网吧')
# else:
#     print('欢迎进入，欢迎充值')

# b.需求2：从控制台输入一个整数，判断该数是否是偶数
# 偶数：能被2整除、2的倍数
# 整除/倍数：num1 % num2 == 0
# num = int(input('请输入一个整数：'))
# # 注意：=和==的区别
# if num % 2 == 0:
#     print(f"{num}是偶数")
# else:
#     print(f"{num}是奇数")

# c.从控制台输入一个整数，判断该数是否是7的倍数
num = int(input('请输入一个整数：'))
if num % 7 == 0:
    print(f"{num}是7的倍数")
else:
    print(f"{num}不是7的倍数")
