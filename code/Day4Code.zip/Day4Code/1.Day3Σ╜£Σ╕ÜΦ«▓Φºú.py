"""
1.下列哪个语句在Python中是非法的？（）
A. x = y = z = 1
B. x = (y = z + 1)
C. x, y = y, x
D. x = y
"""
y = 2
z = 0
# 错误写法，原因：y = z + 1，只是将z+1的结果赋值给y,但是，y = z + 1整体没结果
# x = (y = z + 1)
# 正确写法一
x = (y == z + 1)
print(x)
# 正确写法二
y = z + 1
x = y
print(x)

# 扩展：
y = z + 1
print(y)

# 已知x = 3 == 3,执行结束后，变量x的值为（）。
x = 3 == 3
print(x)   # True

# 从控制台输入一个三位数，分别拆分出个位数，十位数和百位数，将拆分结果输出，
# 格式为：百位：xx,十位：xx，个位：xx
# 方式一
num = int(input('请输入一个三位数：'))  # 153
bw = num // 100
sw = num // 10 % 10   # num % 100 // 10
gw = num % 10
print(f"百位：{bw},十位：{sw}，个位：{gw}")

# 方式二
# 扩展：xx[index]表示获取列表，元组或字符串中的第index个数据，index从0开始
# 如：s = 'abc'---->s[0]获取的是'a',s[1]获取的是'b',s[2]获取的是'c'
num = input('请输入一个三位数：')   # 153
bw = num[0]
sw = num[1]
gw = num[2]
print(f"百位：{bw},十位：{sw}，个位：{gw}")





