# 1.基本使用
n1 = 34
n2 = 90
if n1 != n2:
    print('yes~~~~~~1111111')
    if n1 < n2:
        print('yes~~~~~22222')
    else:
        print('no~~~~~22222')
else:
    print('no~~~~~1111')

# 2.应用
"""
扩展：
x.isdigit():判断x字符串是否非空且全部由数字组成，如果是则结果为True,反之为False
len(x):获取x字符串的长度
"""
num = input('请输入一个三位数：')  # 153
if num.isdigit():
    if len(num) == 3:
        num = int(num)
        bw = num // 100
        sw = num // 10 % 10  # num % 100 // 10
        gw = num % 10
        print(f"百位：{bw},十位：{sw}，个位：{gw}")
    else:
        print('不是三位数')
else:
    print("输入有误")


