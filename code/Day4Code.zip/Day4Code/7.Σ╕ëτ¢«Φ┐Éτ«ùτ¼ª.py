# 语法：a if 条件 else b
# 工作原理：如果条件成立，则整个表达式的结果为a；如果条件不成立，则整个表达式的结果为b

# 1.代码块的实现：逻辑复杂
num = int(input('请输入一个整数：'))
# 注意：=和==的区别
if num % 2 == 0:
    print(f"{num}是偶数")
else:
    print(f"{num}是奇数")

# 2.三目运算符实现：逻辑简单
num = int(input('请输入一个整数：'))
r1 = '偶数' if num % 2 == 0 else '奇数'
print(r1)
r1 = True if num % 2 == 0 else False
print(r1)