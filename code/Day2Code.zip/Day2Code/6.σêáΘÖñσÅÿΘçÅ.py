# 1.定义变量
name = 'jack'
print(name)

# 2.删除变量
del name
# print(name)  # NameError: name 'name' is not defined

# print(num)   # NameError: name 'num' is not defined