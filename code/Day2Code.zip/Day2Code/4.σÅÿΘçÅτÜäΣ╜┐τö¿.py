# 1.可以给变量重新赋值
name = 'zhangsan'    # 初始值
print(name)
name = '李四'        # 重新赋的值
print(name)

# 2.id(x)：获取数据x在计算机内存中的地址
# 注意：获取一个变量的地址，实际获取的是变量中存储的数据的地址
a1 = 19
print(id(a1))
print(id(19))

# 3.type(x):获取数据x的数据类型
r1 = 66
r2 = '66'
print(r1,r2)
print(type(r1))   # <class 'int'>
print(type(r2))   # <class 'str'>
lst = [34,6,7,8]
print(type(lst))   # <class 'list'>

# 注意：但凡是通过input从控制台输入的数据，都是字符串类型
age = input("请输入你的年龄：")
print(age,type(age))  # 18 <class 'str'>

# 4.常量
# 注意：在程序中，如果希望一个变量表示的值不需要被修改，则将该变量定义为常量
# 变量命名法：所有字母全部小写，不同单词之间使用下划线连接
# 常量命名法：所有字母全部大写，不同单词之间使用下划线连接
PI = 3.1415
print(PI)

# PI = 'gagag'
# print(PI)