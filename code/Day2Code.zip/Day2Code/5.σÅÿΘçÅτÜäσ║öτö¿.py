# 1.交换两个变量的值【面试题】
# a.方式一：增减一个中间变量
num1 = 23
num2 = 88
temp = num1
num1 = num2
num2 = temp
print(num1,num2)

# b.方式二：Python中特有的语法            ********
num1 = 23
num2 = 88
num1,num2 = num2,num1
print(num1,num2)

# c.方式三：加减法
num1 = 23
num2 = 88
num1 = num1 + num2  # num1 = 23 + 88
num2 = num1 - num2  # num2 = 23 + 88 - 88
num1 = num1 - num2  # num1 = 23 + 88 - 23
print(num1,num2)

# d.方式四：异或【自学】

# 2.打包pack和拆包unpack【面试题】
# b1,b2,b3 = 10,20,30,40  # ValueError: too many values to unpack (expected 3)

# *:所有
# a.打包
b1,b2,*b3 = 10,20,30,40,24,56,7,89
print(b1,b2,b3)
b1,*b2,b3 = 10,20,30,40,24,56,7,89
print(b1,b2,b3)
*b1,b2,b3 = 10,20,30,40,24,56,7,89
print(b1,b2,b3)

# b.拆包
a,b,c = [34,56,6]
print(a,b,c)
a,b,c = (34,56,6)
print(a,b,c)
a,b,*c = (34,56,6,56,78)
print(a,b,c)