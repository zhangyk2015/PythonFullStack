# 1.基本定义
# name是变量名/引用/标识符，'zhangsan'是数据，用于给name赋值
# 注意：定义一个变量，相当于在计算机的内存中开辟了一份空间，该空间中存储了一个指定的数据
name = 'zhangsan'
print(name)

# 2.在定义变量的同时可以声明类型，后期才会使用到
num:int = 10

# 3.定义多个变量
# a
a1 = a2 = a3 = 66
print(a1,a2,a3)

# b
b1,b2,b3 = 10,20,30
print(b1,b2,b3)

# 注意：默认情况下，当同时定义多个变量时，变量和数据的数量需要保持一致
# b1,b2,b3 = 10,20,30,40  # ValueError: too many values to unpack (expected 3)
# b1,b2,b3,b4 = 10,20,30 # ValueError: not enough values to unpack (expected 4, got 3)
