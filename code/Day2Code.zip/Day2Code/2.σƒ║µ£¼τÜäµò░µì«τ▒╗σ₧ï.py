# 一、掌握
# 1. 数字型：整型【int】,浮点型【float】,复数【complex】
n1 = 34
n2 = 45.19
n3 = 4 + 8j
print(n1,n2,n3)

# 2. 布尔型：bool,只有两个值：True和False
b1 = True
b2 = False
print(b1,b2)
# 注意：True可以被当做1使用，False可以被当做0使用
print(True + 1)
print(False + 1)

# 3. 字符串型：str
s1 = "3464fahg%$#计算机"
print(s1)
s2 = '3464' \
     'fahg' \
     '%$#' \
     '计算机'
print(s2)
s3 = """3464
fahg
%$#
计算机"""
print(s3)
s4 = '''3464
fahg
%$#
计算机'''
print(s4)

# 二、了解，后期会详细讲解
# 4.列表：list
lst1 = [45,67,8,99]
print(lst1)

# 5.元组：tuple
t1 = (45,67,8,99)
print(t1)

# 6.字典：dict
d1 = {'a':10,'b':20}
print(d1)

# 7.集合：set
set1 = {45,67,8,99}
print(set1)

# 8.字节：bytes
b3 = b'fhajfh'
print(b3)
b3 = b"fhajfh"
print(b3)

# 9.空值：NoneType,只有一个值：None
n = None
print(n)
