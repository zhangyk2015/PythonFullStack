# 1.需求：假设人的最长寿命为130，计算剩余寿命
# 写法一：
# age = input('请输入你的年龄：')
# print(f"剩余寿命:{130 - int(age)}")

# 写法二：
# age = input('请输入你的年龄：')
# age = int(age)  # 重新赋值
# print(f"剩余寿命:{130 - age}")

# 写法三：
age = int(input('请输入你的年龄：'))
print(f"剩余寿命:{130 - age}")


